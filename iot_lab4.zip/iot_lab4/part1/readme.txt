*****Raspberries lab 4 README*****

For this lab, we implemented 4 services for our IOT-DDL functionality. The 4 services are LED blinking, button turning on LED, 
buzzer buzzing, and distance measurer. All the services are included and well documented in both the C++ and XML files attached in this lab submission.

Distribusion of effort:
- Lior wrote the LED and Buzzer services.
- Doron wrote the Button service.
- Daniel wrote the Distance measure service.
- All 3 of us wrote the API python script together. The script uses sockets to listen to the ATLAS middleware and invoke services on the pi
using tweets.


We generated the XML file as was demonstrated in class and in the PDF file of the lab.
Aditionally we did the extra credit with Group 11. 
Any demonstration of the functionality of the services will be available upon request.

Thank you,
The Raspberries